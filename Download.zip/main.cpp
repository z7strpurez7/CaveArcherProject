#include <iostream>
#include "DEFINITIONS.h"
#include "Engine/Game.h"
int main()
{

   Game game(SCREEN_WIDTH, SCREEN_HEIGHT, GAME_NAME);
   return EXIT_SUCCESS;

}
