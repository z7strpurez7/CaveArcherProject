# CaveArcherProject
Welcome to CaveArcher
This game is currently under development. In order to run the program go to
cmake-build-release and run the platformshooter2d.exe file. The folder should contain all the necessary dlls needed.

The game does not end after defeating the boss, press ESCAPE on your keyboard to leave the game.
GAME CONTROLDS: WASD + MOUSE, 1 and 2 to swap weapons(animation and new weapon not added for the second weapon yet),
but it changes range and firerate on the weapon at the moment.

